﻿// When you have others classes in /Models you can delete this file
// (there is a @using $safeprojectname$.Models in _ViewImports.cshtml

namespace $safeprojectname$.Models
{
    public class MyModel
    {
    }
}
